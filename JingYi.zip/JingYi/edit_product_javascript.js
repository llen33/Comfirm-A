function confirmEditProduct() {
    return confirm("Are you sure you want to edit this product?");
}