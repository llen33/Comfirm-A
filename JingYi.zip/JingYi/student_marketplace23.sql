-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2023-06-28 11:59:57
-- 服务器版本： 10.4.28-MariaDB
-- PHP 版本： 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `student_marketplace23`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_name` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `admin_login`
--

INSERT INTO `admin_login` (`admin_name`, `admin_password`) VALUES
('thiviyaa', 'csd21010'),
('bhuant', 'csd21003'),
('jingyi', 'csd21005'),
('ellen', 'csd21007');

-- --------------------------------------------------------

--
-- 表的结构 `buyer`
--

CREATE TABLE `buyer` (
  `buyer_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `buyer`
--

INSERT INTO `buyer` (`buyer_id`, `user_id`) VALUES
(1, 22),
(2, 24),
(3, 25),
(4, 26),
(5, 27),
(6, 30),
(7, 34);

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

CREATE TABLE `cart` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(0, 'test', '3.00', '', 1),
(0, 'huhuh', '30.00', '', 1);

-- --------------------------------------------------------

--
-- 表的结构 `image`
--

CREATE TABLE `image` (
  `image_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `path` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `image`
--

INSERT INTO `image` (`image_id`, `product_id`, `path`) VALUES
(21, 17, 'uploaded_img/CT6551-010-PHSFH001-1000.jpg'),
(22, 18, 'uploaded_img/m_g-gel-pen-r3-0.5mm.jpg'),
(23, 19, 'uploaded_img/book-1.png'),
(24, 10, 'uploaded_img/_used__ipad_air_1_32gb_wifi__a_1677149848_8d6d85c1.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `order`
--

CREATE TABLE `order` (
  `id` int(255) NOT NULL,
  `name` varchar(500) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `method` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin_code` int(10) NOT NULL,
  `total_products` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `order`
--

INSERT INTO `order` (`id`, `name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `pin_code`, `total_products`, `total_price`, `country`) VALUES
(1, '0', '01164896041', 'bhuant09@gmail.com', '0', 'Block 3,13 floor,1 house Desa mawar,lintang kampung melayu 2', 'Farlim', 'Air itam', 'Penang', 11500, 'burger (1) ', '16', 'MALAYSIA'),
(2, '0', '01164896041', 'bhuant09@gmail.com', '0', 'Block 3,13 floor,1 house Desa mawar,lintang kampung melayu 2', 'Farlim', 'Air itam', 'Penang', 11500, 'Nokia (5) ', '450', 'MALAYSIA');

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `quantity` int(10) DEFAULT NULL,
  `product_condition` varchar(255) DEFAULT NULL,
  `seller_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `description`, `category`, `quantity`, `product_condition`, `seller_id`) VALUES
(10, 'Used Ipad Mini 2017', 700.00, 'Used', 'Electronic', 1, '7/10', 8),
(17, 'Nike Shirt Preloved', 10.00, 'test', 'Cloth', 1, 'test', 9),
(18, 'Pen 3 pcs', 3.00, 'Test', 'Stationary', 1, 'New', 12),
(19, 'Think like monk by Jay Shetty', 10.00, 'Preloved book by jay shetty', 'Book', 1, '10/10', 11);

-- --------------------------------------------------------

--
-- 表的结构 `seller`
--

CREATE TABLE `seller` (
  `seller_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `seller`
--

INSERT INTO `seller` (`seller_id`, `user_id`) VALUES
(7, 20),
(8, 21),
(9, 23),
(10, 31),
(11, 32),
(12, 33);

-- --------------------------------------------------------

--
-- 表的结构 `test_order`
--

CREATE TABLE `test_order` (
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(10) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` enum('Pending','Shipped') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `test_order`
--

INSERT INTO `test_order` (`user_id`, `product_id`, `name`, `price`, `quantity`, `total`, `order_id`, `status`) VALUES
(0, 12, 'shoe', 3.00, 2, 9.00, 17, 'Pending'),
(0, 12, 'shoe', 3.00, 2, 12.00, 20, 'Pending'),
(0, 11, 'test', 3.00, 2, 12.00, 21, 'Pending'),
(0, 12, 'shoe', 3.00, 1, 3.00, 22, 'Pending'),
(0, 12, 'shoe', 3.00, 1, 3.00, 23, 'Pending'),
(0, 11, 'test', 3.00, 2, 6.00, 24, 'Pending'),
(0, 10, 'huhuh', 30.00, 1, 30.00, 25, 'Pending'),
(0, 11, 'test', 3.00, 1, 3.00, 26, 'Pending'),
(0, 10, 'huhuh', 30.00, 1, 39.00, 27, 'Pending'),
(0, 11, 'test', 3.00, 2, 39.00, 28, 'Pending'),
(0, 13, 'tvyanew', 3.00, 1, 39.00, 29, 'Pending'),
(0, 11, 'test', 3.00, 3, 9.00, 30, 'Pending'),
(0, 10, 'huhuh', 30.00, 1, 30.00, 31, 'Pending'),
(0, 11, 'test', 3.00, 1, 3.00, 33, 'Pending'),
(0, 11, 'test', 3.00, 1, 3.00, 34, 'Pending'),
(0, 11, 'test', 3.00, 4, 12.00, 35, 'Pending'),
(27, 11, 'test', 3.00, 1, 3.00, 36, 'Pending'),
(27, 10, 'huhuh', 30.00, 1, 30.00, 37, 'Shipped'),
(30, 11, 'test', 3.00, 2, 39.00, 38, 'Pending'),
(30, 10, 'huhuh', 30.00, 1, 39.00, 39, 'Shipped'),
(30, 13, 'tvyanew', 3.00, 1, 39.00, 40, 'Pending'),
(31, 14, 'Nike Shirt Preloved', 10.00, 2, 20.00, 41, 'Pending'),
(27, 11, 'test', 3.00, 1, 3.00, 42, 'Pending'),
(23, 15, 'Shoe', 10.00, 2, 20.00, 43, 'Pending'),
(27, 13, 'tvyanew', 3.00, 2, 6.00, 44, 'Pending'),
(23, 14, 'Nike Shirt Preloved', 10.00, 1, 10.00, 45, 'Pending'),
(23, 16, 'stationary ', 3.00, 1, 3.00, 46, 'Pending'),
(27, 16, 'stationary ', 3.00, 1, 3.00, 47, 'Pending'),
(27, 10, 'huhuh', 30.00, 4, 120.00, 48, 'Shipped'),
(27, 14, 'Nike Shirt Preloved', 10.00, 1, 10.00, 49, 'Pending'),
(26, 10, 'huhuh', 30.00, 1, 30.00, 50, 'Shipped'),
(27, 14, 'Nike Shirt Preloved', 10.00, 1, 10.00, 51, 'Pending'),
(27, 10, 'huhuh', 30.00, 4, 120.00, 52, 'Shipped'),
(27, 18, 'Pen 3 pcs', 3.00, 1, 3.00, 53, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 54, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 55, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 56, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 57, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 58, 'Pending'),
(27, 0, '', 0.00, 0, 0.00, 59, 'Pending'),
(27, 0, '', 10.00, 0, 0.00, 60, 'Pending'),
(27, 0, '', 40.00, 0, 0.00, 61, 'Pending'),
(27, 0, '', 3.00, 0, 0.00, 62, 'Pending'),
(27, 18, 'Pen 3 pcs', 3.00, 1, 3.00, 63, 'Pending'),
(34, 19, 'Think like monk by Jay Shetty', 10.00, 1, 10.00, 64, 'Pending'),
(34, 19, 'Think like monk by Jay Shetty', 10.00, 2, 20.00, 65, 'Pending');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `home_address` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `bio` varchar(1000) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `school` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `username`, `password`, `email`, `phone_number`, `home_address`, `role`, `gender`, `bio`, `birthdate`, `school`) VALUES
(20, 'bhuant', 'gg', 'messi', '1234', 'bhuant09@gmail.com', '01164896041', 'Block 3,13 floor,1 house Desa mawar,lintang kampung melayu 2', 'seller', NULL, NULL, NULL, NULL),
(21, 'luffy', 'monkey', 'luffy', '4321', 'bhuant90@gmail.com', '0192839922', 'Block 3,13 floor,1 house Desa mawar,lintang kampung melayu 2', 'seller', NULL, NULL, NULL, NULL),
(22, 'naruto', 'uzumaki', 'naruto', '2425', 'bhuant90@gmail.com', '0192839922', 'Block 3,13 floor,1 house Desa mawar,lintang kampung melayu 2', 'buyer', NULL, NULL, NULL, NULL),
(23, 'Thiviyaa', 'Sarawanan', 'test2323', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'seller', 'Female', 'Test', '2003-02-23', 'Disted College,Penang'),
(24, 'Thiviyaa', 'Sarawanan', 'test24', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(25, 'Thiviyaa', 'Sarawanan', 'tvyauser', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(26, 'Thiviyaa', 'Sarawanan', 'tvyabuyer', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(27, 'Thiviyaa', 'Sarawanan', 'lufi', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(28, 'Thiviyaa', 'Sarawanan', 'turu', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(30, 'Thiviyaa', 'Sarawanan', 'joji', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL),
(31, 'Thiviyaa', 'Sarawanan', 'seller23', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'seller', NULL, NULL, NULL, NULL),
(32, 'Thiviyaa', 'Sarawanan', 'june', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'seller', NULL, NULL, NULL, NULL),
(33, 'Thiviyaa', 'Sarawanan', 'june2', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'seller', NULL, NULL, NULL, NULL),
(34, 'Thiviyaa', 'Sarawanan', 'july', '1234', 'tvyatvya2003@gmail.com', '0175506860', '15-5-05 Sri Impian,lengkok angsana,bandar baru air itam', 'buyer', NULL, NULL, NULL, NULL);

--
-- 转储表的索引
--

--
-- 表的索引 `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`buyer_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- 表的索引 `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- 表的索引 `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`seller_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `test_order`
--
ALTER TABLE `test_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `buyer`
--
ALTER TABLE `buyer`
  MODIFY `buyer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `image`
--
ALTER TABLE `image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- 使用表AUTO_INCREMENT `seller`
--
ALTER TABLE `seller`
  MODIFY `seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `test_order`
--
ALTER TABLE `test_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- 限制导出的表
--

--
-- 限制表 `buyer`
--
ALTER TABLE `buyer`
  ADD CONSTRAINT `buyer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `image_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- 限制表 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `seller` (`seller_id`);

--
-- 限制表 `seller`
--
ALTER TABLE `seller`
  ADD CONSTRAINT `seller_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
