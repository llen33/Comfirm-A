function confirmEditProfile() {
    return confirm("Are you sure you want to save it?");
}