<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="libs/css/custom.css">
    <link rel="icon" href="libs/brandlogo.jpg" >
    <title>Thrifts Depot</title>
</head>
<body>
    <h1>Thrifts Depot</h1>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="products.php">Products</a></li>
       
        <li style="float:right"><a class="active" href="">Sign in / Sign up</a></li>

        <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div class="page-header">
                <h1><?php echo isset($page_title) ? $page_title : ""; ?></h1>
            </div>
        </div>
      </ul>

      <article class="all-browsers">
        <h1>Welcome to Thrifts Depot Disted College</h1>
        <article class="browser">
          <h2>Sell</h2>
          <p> Click here to sell</p>
        </article>
        <article class="browser">
          <h2>Find</h2>
          <p><a href="products.php">Click here to buy</a> </p>
        </article>
      </article>
      
      <footer>
        <p>Thrifts Depot 2023<br>
        <a href="thriftsdepot@gmail.com">thriftsdepot@gmail.com || </a>
        <a href="">About Us</a></p>
      </footer>

    
      
</body>
</html>