<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- custom css for users -->
    <link href="libs/css/custom.css" rel="stylesheet" media="screen">
    <link rel="icon" href="libs/brandlogo.jpg">
</head>

<body>
    <?php include 'navigation.php'; ?>

    <!-- container -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-header">
                    <h1>
                      
                    </h1>
                </div>
            </div>