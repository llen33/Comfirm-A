<?php
@include "config.php";

?>

<!DOCTYPE html>
<html>

<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign up</title>
        <link rel="stylesheet" type="text/css" href="style.css" title="style" />
</head>

<body>

<div>
    <?php

    if(isset($_POST['submit'])){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $phone_number = $_POST['phone_number'];
        $home_address = $_POST['home_address'];
        
        $insert = "INSERT INTO users (firstname, lastname, username, email, password, phone_number, home_address) VALUES('$firstname', '$lastname', '$username', '$email', '$password', '$phone_number', '$home_address')";
        $upload = mysqli_query($conn, $insert);

            if($upload){
                echo 'Successfully saved.';
            }
            else{
                echo 'There was error while saving data';
            }
        }
    ?>
</div>



<div class = regispage>
    <h1>Sign Up</h1>

    <form name="registration" action="signup.php" method="post">
        <div class="regisform">
            <label for="firstname"><b>First Name</b></label><br>
            <input type="text" name="firstname" placeholder="First name" required ><br>
            
            <label for="lastname"><b>Last Name</b></label><br>
            <input type="text" name="lastname" placeholder="Last name" required ><br>
                
            <label for="username"><b>Username</b></label><br>
            <input type="text" name="username" placeholder="Username" required ><br>

            <label for="email"><b>Email Address</b></label><br>
            <input type="email" name="email" placeholder="Email" required ><br>
                
            <label for="password"><b>Password</b></label><br>
            <input type="password" name="password" placeholder="Password" required ><br>
                
            <label for="phone_number"><b>Contact Number</b></label><br>
            <input type="text" name="phone_number" placeholder="Contact Number" required ><br>
                    
            <label for="home_address"><b>Home Address</b></label><br>
            <input type="text" name="home_address" placeholder="home address" required ><br>

            <input type="submit" name="submit" value="Sign Up" >
    </form>
                
        <p>Already have a member? <a href='login.php'>Login Here</a></p>
</div>
</body>
</html>
