<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track My Parcel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .track-form {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .track-input {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .track-button {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .track-results {
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border: 1px solid #ccc;
        }
    </style>
</head>

<body>
    <h1>Track My Parcel</h1>
    <div class="track-form">
        <form method="POST" action="track_info.php">
            <input type="text" class="track-input" name="name" placeholder="Enter product name">
            <button type="submit" class="track-button">Track</button>
        </form>
    </div>
    <div class="track-results">
        <!-- The tracking results will be displayed here -->
    </div>
</body>

</html>
