<?php
session_start();
@include 'config.php';

// Include database connection and other necessary functions here

if (isset($_POST['product_id'])) {
    $id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Fetch the product details from the database
    $productQuery = mysqli_query($conn, "SELECT * FROM products WHERE product_id = $id");
    $product = mysqli_fetch_assoc($productQuery);

    // Add the product to the cart
    $cartItem = [
        'id' => $product['product_id'],
        'name' => $product['name'],
        'price' => $product['price'],
        'quantity' => $quantity
    ];

    // Check if the cart session variable exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the product is already in the cart
    $existingItem = array_search($product['product_id'], array_column($_SESSION['cart'], 'id'));

    if ($existingItem !== false) {
        // Update the quantity of the existing item
        $_SESSION['cart'][$existingItem]['quantity'] += $quantity;
    } else {
        // Add the new item to the cart
        $_SESSION['cart'][] = $cartItem;
    }

    header('location: test_cart.php');
    exit();
}
?>
