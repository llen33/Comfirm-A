<?php
session_start();
@include 'config.php';

// Check if the cart is empty
if (empty($_SESSION['cart'])) {
    header('location: test_cart.php');
    exit();
}

// Calculate the total price
$totalPrice = 0;
foreach ($_SESSION['cart'] as $cartItem) {
    $totalPrice += $cartItem['price'] * $cartItem['quantity'];
}

// Insert order details into the test_order table
foreach ($_SESSION['cart'] as $cartItem) {
    $productId = $cartItem['id'];
    $productName = $cartItem['name'];
    $quantity = $cartItem['quantity'];
    $price = $cartItem['price'];

    $insertQuery = "INSERT INTO test_order (product_id, name, quantity, price, total) VALUES ('$productId', '$productName', '$quantity', '$price', '$totalPrice')";
    mysqli_query($conn, $insertQuery);
}

// Clear the cart after the order is placed
unset($_SESSION['cart']);

header('location: test_order_confirmation.php');
exit();
?>
