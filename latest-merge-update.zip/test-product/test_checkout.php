<?php
session_start();
@include 'config.php';

// Redirect the user to the cart page if the cart is empty or not set
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart']) || count($_SESSION['cart']) === 0) {
    header('location: test_cart.php');
    exit();
}

// Calculate the total price of all items in the cart
$totalPrice = 0;
foreach ($_SESSION['cart'] as $cartItem) {
    $totalPrice += $cartItem['price'] * $cartItem['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 5px;
        }

        .total-price {
            font-size: 20px;
            font-weight: bold;
            text-align: right;
            margin-top: 20px;
        }

        .payment-form {
            margin-top: 20px;
            text-align: center;
        }

        .payment-btn,
        .back-to-cart-btn {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .payment-btn:hover {
            background-color: #0056b3;
        }

        .back-to-cart-btn {
            background-color: #000;
        }

        .back-to-cart-btn:hover {
            background-color: #333;
        }
    </style>
</head>

<body>
    <h1>Checkout</h1>
    <table>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>
        <?php
        foreach ($_SESSION['cart'] as $cartItem) {
            // Fetch the product details from the database
            $productQuery = mysqli_query($conn, "SELECT * FROM products WHERE product_id = " . $cartItem['id']);
            $product = mysqli_fetch_assoc($productQuery);

            // Retrieve the image path for the current product
            $result = mysqli_query($conn, "SELECT * FROM image WHERE product_id = " . $cartItem['id']);
            $image = mysqli_fetch_assoc($result);

            $total = $cartItem['quantity'] * $product['price'];
            ?>
            <tr>
                <td><img src="<?php echo $image['path']; ?>" alt="Product Image"></td>
                <td><?php echo $product['name']; ?></td>
                <td><?php echo $product['price']; ?></td>
                <td><?php echo $cartItem['quantity']; ?></td>
                <td><?php echo $total; ?></td>
            </tr>
        <?php } ?>
    </table>
    <div class="total-price">
        Total Price:RM <?php echo $totalPrice; ?>
    </div>
    <div class="payment-form">
        <form action="test_order.php" method="post">
            <!-- Include any additional input fields for the payment form -->
            <button type="submit" class="payment-btn">Make Payment</button>
        </form>
    </div>
    <div class="back-to-cart">
        <a href="test_cart.php" class="back-to-cart-btn">Go Back to Cart</a>
    </div>
</body>

</html>
