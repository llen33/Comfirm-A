<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

@include 'test_config.php';

if (isset($_GET['add_to_cart'])) {
    $id = $_GET['add_to_cart'];

    // Fetch the product details from the database
    $productQuery = mysqli_query($conn, "SELECT * FROM products WHERE product_id = $id");
    $product = mysqli_fetch_assoc($productQuery);

    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        // Add the product to the cart
        $cartItem = [
            'id' => $product['product_id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => 1
        ];

        // Check if the cart session variable exists
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Check if the product is already in the cart
        $existingItem = array_search($product['product_id'], array_column($_SESSION['cart'], 'id'));

        if ($existingItem !== false) {
            // Update the quantity of the existing item
            $_SESSION['cart'][$existingItem]['quantity'] += 1;
        } else {
            // Add the new item to the cart
            $_SESSION['cart'][] = $cartItem;
        }

        header('location: test_cart.php');
        exit();
    } else {
        // User is not logged in, redirect to the login page
        header('location: login.php');
        exit();
    }
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List - Bhuant </title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">


    <style>
        * {
            margin: 0px;
            padding: auto;
            box-sizing: border-box;
            font-family: 'Ubuntu', sans-serif;
        }

        div.header {
            font-family: Arial, Helvetica, sans-serif;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0px 60px;
            color: black;
        }

        div.header button {
            font-size: 16px;
            padding: 8px 12px;
            border: 2px solid black;
            border-radius: 5px;
            color: white;
            background-color: black;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins&family=Ubuntu:wght@300;700&display=swap');

        .navbar {
            background-color: #222;
            display: flex;
            justify-content: space-around;
            align-items: center;
            line-height: 5rem;
        }

        h2 {
            text-align: center;
        }

        .left h1 {
            font-size: 2.5rem;
            cursor: pointer;
            color: white;
        }

        .right ul {
            display: flex;
            list-style: none;
        }

        .right ul li a {
            padding: 10px 20px;
            font-size: 1.2rem;
            color: white;
            cursor: pointer;
            text-decoration: none;
            transition: all 1s;
        }

        .right ul li a:hover {
            background-color: #fff;
            border-radius: 7px;
            color: rgb(22, 7, 36);
        }

        @media screen and (max-width:805px) {
            .list {
                width: 100%;
                height: 100vh;
                background-color: rgb(22, 7, 36);
                text-align: center;
                display: flex;
                flex-direction: column;
                position: fixed;
                top: 4rem;
                left: 100%;
                transition: all 1s;
            }
        }

        .product-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .card {
            width: 300px;
            margin: 20px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            text-align: center;
        }

        .card-image img {
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .card-price {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .card-description {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .card-category {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .card-quantity {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .card-condition {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .add-to-cart-button {
            display: inline-block;
            background-color: #007bff;
            color: #fff;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .add-to-cart-button:hover {
            background-color: #0056b3;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
        }

        .update-cart-button {
            display: inline-block;
            background-color: #28a745;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .update-cart-button:hover {
            background-color: #1e7e34;
        }

        .cart-icon {
            position: relative;
            display: inline-block;
        }

        .cart-icon i {
            font-size: 24px;
            color: #007bff;
        }

        .cart-icon .cart-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #007bff;
            color: #fff;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="left">
            <h1>Thrifts Depot</h1>
        </div>

        <div class="right">
        <ul class="list">
                <li><a href="/Ellen_login1234/index_buyer.php">Home</a></li>
                <li><a href="/test-product/test.php">Products</a></li>
                <li><a href="#">My Profile</a></li>
                <li><a href="#">My Order</a></li>
                <li><a href="#">Track Parcel</a></li>
            </ul>
        </div>
    </nav>

    <div class="product-list">
        <?php
        $select = mysqli_query($conn, "SELECT * FROM products");
        $rows = mysqli_fetch_all($select, MYSQLI_ASSOC);

        foreach ($rows as $row) :
        ?>
            <div class="card">
                <div class="card-image">
                    <?php
                    // Retrieve images for the current product
                    $product_id = $row['product_id'];
                    $result = mysqli_query($conn, "SELECT * FROM image WHERE product_id = $product_id");
                    $images = mysqli_fetch_all($result, MYSQLI_ASSOC);

                    if (!empty($images)) {
                        $image = $images[0];
                        echo '<img src="' . $image['path'] . '" alt="Product Image">';
                    }
                    ?>
                </div>
                <div class="card-details">
                    <h3 class="card-title"><?php echo $row['name']; ?></h3>
                    <p class="card-price">Price: <?php echo $row['price']; ?> RM</p>
                    <p class="card-description"><?php echo $row['description']; ?></p>
                    <p class="card-category">Category: <?php echo $row['category']; ?></p>
                    <form action="test_config.php" method="post">
                        <p class="card-quantity">
                            Quantity:
                            <input type="number" name="quantity" value="1" min="1" class="quantity-input">
                            <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                        </p>
                        <p class="card-condition">Condition: <?php echo $row['product_condition']; ?></p>
                        <button type="submit" class="add-to-cart-button">Add to Cart</button>
                    </form>
                </div>
            </div>
        <?php
        endforeach;
        ?>
        <div class="cart-icon">
            <a href="test_cart.php">
                <i class="fas fa-shopping-cart"></i>
                <span class="cart-count"><?php echo count($_SESSION['cart']); ?></span>
            </a>
        </div>
    </div>

    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Thrifts Depot</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Penang 11500 Malaysia
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:010-020-0340">010-776 0340</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:info@company.com">thriftsdepot@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Categories</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="">Clothes</a></li>
                        <li><a class="text-decoration-none" href="">Books</a></li>
                        <li><a class="text-decoration-none" href="">Electronic Gadgets</a></li>
                        <li><a class="text-decoration-none" href="">Others</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Learn More</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="about.html">About Us</a></li>
                        <li><a class="text-decoration-none" href="">Contact us</a></li>
                        <li><a class="text-decoration-none" href="">FAQs</a></li>
                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <p class="text-left text-light">Follow us on our Social Media Platforms to get instant updates<a rel="sponsored" target="_blank"></a></p>
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; 2023 Thrifts Depot
                            || <a rel="sponsored" target="_blank" href="https://www.disted.edu.my/">by Disted College Students</a>
                            ||<a class="sponsored" target="_blank" href="/admin_login/admin_login.php"> Admin Panel</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->

    <!-- Start Script -->
    <div>
        <script src="assets/js/jquery-1.11.0.min.js"></script>
        <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/templatemo.js"></script>
        <script src="assets/js/custom.js"></script>
    </div>
    <!-- End Script -->

</body>

</html>