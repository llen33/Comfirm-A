<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Parcel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .track-results {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ccc;
        }

        .go-back-button {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <h1>Track Parcel</h1>
    <div class="track-results">
        <?php
        // Assuming you have a database connection already established
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "student_marketplace23";

        // Retrieve the product name input from the previous page
        $product_name = $_POST['name'];

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and execute the query to search for the product
        $stmt = $conn->prepare("SELECT * FROM test_order WHERE name = ?");
        $stmt->bind_param("s", $product_name);
        $stmt->execute();
        $result = $stmt->get_result();

        // Display the tracking information
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Product ID</th><th>Product Name</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['product_id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "<p>Status: Seller is preparing to ship out</p>";
        } else {
            echo "<p>No tracking information found for the given product name.</p>";
        }

        // Close the statement and database connection
        $stmt->close();
        $conn->close();
        ?>
    </div>

    <div class="go-back">
        <button class="go-back-button" onclick="window.location.href='/Ellen_login1234/index_buyer.php'">Go Back</button>
    </div>
</body>

</html>
