<?php
session_start();
if (!isset($_SESSION['AdminLoginId'])) {
    header("Location:admin_login.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="">

    <title>Thrifts Depot</title>

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="final-project/homepage/assets/css/fontawesome.min.css">

    <style>
        * {
            margin: 0px;
            padding: auto;
            box-sizing: border-box;

        }

        div.header {
            font-family: Arial, Helvetica, sans-serif;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0px 60px;
            color: black;
        }

        div.header button {
            font-size: 16px;
            padding: 8px 12px;
            border: 2px solid black;
            border-radius: 5px;
            color: white;
            background-color: black;
        }
        h2 {
            text-align: center;
        }

        .navbar {
            background-color: #222;
            display: flex;
            justify-content: space-around;
            align-items: center;
            line-height: 5rem;
        }

        .left h1 {
            font-size: 2.5rem;
            cursor: pointer;
            color: white;
        }

        .checkBtn {
            display: none;
        }

        .right ul {
            display: flex;
            list-style: none;
        }

        .right ul li a {
            padding: 10px 20px;
            font-size: 1.2rem;
            color: white;
            cursor: pointer;
            text-decoration: none;
            transition: all 1s;
        }

        .right ul li a:hover {
            background-color: #fff;
            border-radius: 7px;
            color: rgb(22, 7, 36);
        }

        @media screen and (max-width:805px) {
            .list {
                width: 100%;
                height: 100vh;
                background-color: rgb(22, 7, 36);
                text-align: center;
                display: flex;
                flex-direction: column;
                position: fixed;
                top: 4rem;
                left: 100%;
                transition: all 1s;
            }


        }

        footer {
            background-color: #222;
            color: #fff;
            font-size: 14px;
            bottom: 0;
            position: fixed;
            left: 0;
            right: 0;
            text-align: center;
            z-index: 999;
        }

        footer p {
            margin: 10px 0;
        }

        footer i {
            color: red;
        }

        footer a {
            color: #3c97bf;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <nav class="navbar">

        <div class="left">
            <h1>Thrifts Depot</h1>
        </div>
        <div class="right">
            <ul class="list">
                <li><a href="#">Dashboard</a></li>
                <li><a href="/final-project/Thiviyaa/seller_info.php">Seller Info</a></li>
                <li><a href="/final-project/Thiviyaa/product_info.php">Product Info</a></li>
                <li><a href="#">Verify Payment</a></li>
            </ul>
        </div>
    </nav>

    <form method="POST">
        <div class="header">
            <h1>Welcome to Admin Panel,
                <?php echo $_SESSION['AdminLoginId'] ?>
            </h1>
            <button type="submit" name="Logout"> Logout </button>
        </div>
    </form>

    <h2>Page to Admin Handle Seller Database</h2>

    <footer>
        <p>Thrifts Depot 2023<br>
            <a href="thriftsdepot@gmail.com"> thriftsdepot@gmail.com || </a>
            <a href="/final-project/homepage/index.php">Homepage || </a>
            <a href="/final-project/Thiviyaa/admin_login.php">Admin Panel</a>
        </p>
    </footer>


    <?php
    if (isset($_POST['Logout'])) {
        session_destroy();
        header("Location:/final-project/Thiviyaa/admin_login.php");
    }
    ?>

</body>

</html>