<?php

$con=mysqli_connect("localhost", "root", "", "thrifts_depot1");

if(mysqli_connect_error())
{
  echo"Error";
}


?>