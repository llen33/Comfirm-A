<?php

    $conn = mysqli_connect('localhost', 'root', '', 'thrifts_depot1')
    
?>