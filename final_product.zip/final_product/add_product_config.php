<?php

    $conn = mysqli_connect('localhost', 'root', '', 'student_marketplace23')
    
?>