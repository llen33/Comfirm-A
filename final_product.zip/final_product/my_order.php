<?php
session_start();
include "config.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch order details for the logged-in user
$userId = $_SESSION['user_id'];
$query = "SELECT * FROM test_order WHERE user_id = '$userId'";
$result = mysqli_query($conn, $query);

// Check if any orders were found
if (mysqli_num_rows($result) > 0) {
    // Display order details
    $orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $orders = [];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .order-details {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
        }

        .go-back-button {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <h1>Track Parcel</h1>

    <?php if (!empty($orders)) : ?>
        <?php foreach ($orders as $order) : ?>
            <div class="order-details">
                <strong>Order ID:</strong> <?php echo $order['order_id']; ?><br>
                <strong>Product ID:</strong> <?php echo $order['product_id']; ?><br>
                <strong>Product Name:</strong> <?php echo $order['name']; ?><br>
                <strong>Quantity:</strong> <?php echo $order['quantity']; ?><br>
                <strong>Price:</strong> <?php echo $order['price']; ?><br>
                <strong>Total:</strong> <?php echo $order['total']; ?><br>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <p>No orders found.</p>
    <?php endif; ?>

    <div class="go-back">
        <button class="go-back-button" onclick="window.location.href='index_buyer.php'">Go Back</button>
    </div>
</body>

</html>
