<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>


<div class="form">

    <form action="loginn.php" method="post" name="login">

        <h1>Log In</h1>

        <?php if (isset($_GET['error'])) { ?>
            <p class='error'><?php echo $_GET['error']; ?><p/>
        <?php } ?>


        <label for="username"><b>Username</b></label><br>
        <input type="text" name="username" placeholder="Username"><br>

        <label for="password"><b>Password</b></label><br>
        <input type="password" name="password" placeholder="Password"><br>

        <input name="submit" type="submit" value="Login" />

    </form>

    <p>Not registered yet? <a href='signup.php'>Register Here</a></p>

</div>

</body>
</html>