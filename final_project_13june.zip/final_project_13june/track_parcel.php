<?php
session_start();
include "config.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch order details for the logged-in user
$userId = $_SESSION['user_id'];
$query = "SELECT * FROM test_order WHERE user_id = '$userId'";
$result = mysqli_query($conn, $query);

// Check if any orders were found
if (mysqli_num_rows($result) > 0) {
    $orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $orders = [];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Parcel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ccc;
        }

        .go-back-button {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .product-image {
            max-width: 100px; /* Adjust the width as needed */
            max-height: 100px; /* Adjust the height as needed */
        }
    </style>
</head>

<body>
    <h1>Track Parcel</h1>
    <?php if (!empty($orders)) : ?>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Product ID</th>
                <th>Image</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
            <?php foreach ($orders as $order) : ?>
                <tr>
                    <td><?php echo $order['order_id']; ?></td>
                    <td><?php echo $order['product_id']; ?></td>
                    <td>
                        <?php
                        // Retrieve images for the current product
                        $product_id = $order['product_id'];
                        $result = mysqli_query($conn, "SELECT * FROM image WHERE product_id = $product_id");
                        $images = mysqli_fetch_all($result, MYSQLI_ASSOC);

                        if (!empty($images)) {
                            $image = $images[0];
                            echo '<img src="' . $image['path'] . '" alt="Product Image" class="product-image">';
                        }
                        ?>
                    </td>
                    <td><?php echo $order['name']; ?></td>
                    <td><?php echo $order['quantity']; ?></td>
                    <td><?php echo $order['price']; ?></td>
                    <td><?php echo $order['total']; ?></td>
                    <td>Seller is preparing to ship out</td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else : ?>
        <p>No tracking information found for the given user.</p>
    <?php endif; ?>

    <div class="go-back">
        <button class="go-back-button" onclick="window.location.href='index_buyer.php'">Go Back</button>
    </div>
</body>

</html>
