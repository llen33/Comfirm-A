function confirmResetPassword() {
    return confirm("Are you sure you want to reset your password?");
}