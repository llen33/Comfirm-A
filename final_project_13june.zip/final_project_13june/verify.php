<?php
// Include the config.php file for database connection
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted username from the form
    $username = $_POST['username'];

    // Perform the verification logic here, such as updating the database or performing an action
    // You can use the $username variable to identify the seller to be verified

    // Example: Update the 'verified' field in the users table for the seller with the submitted username
    $stmt = $conn->prepare("UPDATE users SET verified = 1 WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();

    // Redirect back to the seller info page after verification
    header("Location: seller_info.php");
    exit();
}

// Close the database connection
$conn->close();
?>
