function confirmAddProduct() {
    return confirm("Are you sure you want to add this product?");
}