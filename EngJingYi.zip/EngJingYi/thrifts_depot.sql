CREATE TABLE products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  price DECIMAL(10, 2),
  description VARCHAR(1000),
  category VARCHAR(255),
  quantity int(10),
  product_condition VARCHAR(255),
  seller_id INT NOT NULL,
  FOREIGN KEY (seller_id) REFERENCES seller(seller_id)
);

CREATE TABLE image (
  image_id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT,
  path VARCHAR(200),
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);