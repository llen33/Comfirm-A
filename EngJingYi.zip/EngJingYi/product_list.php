<?php

    @include 'add_product_config.php';

    if(isset($_GET['delete'])){

        $id = $_GET['delete'];

        mysqli_query($conn, "DELETE FROM image WHERE product_id = $id");

        mysqli_query($conn, "DELETE FROM products WHERE product_id = $id");

        header('location:product_list.php');

    };

?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Product Added List Page</title>

        <!-- font awesome cdn link  -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        
    </head>

    <body>
        
        <div class="container">

            <?php

                $select = mysqli_query($conn, "SELECT * FROM products");
                $rows = mysqli_fetch_all($select, MYSQLI_ASSOC);

            ?>

            <div class="product-list">

                <table class="product-list-table">

                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Product Price (RM)</th>
                            <th>Product Description</th>
                            <th>Product Category</th>
                            <th>Product Quantity</th>
                            <th>Product Condition</th>
                            <th>Product Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <?php 
                    
                        foreach ($rows as $row): 
                        
                    ?>

                        <tr>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><?php echo $row['description']; ?></td>
                            <td><?php echo $row['category']; ?></td>
                            <td><?php echo $row['quantity']; ?></td>
                            <td><?php echo $row['product_condition']; ?></td>
                            <td>

                                <?php
                                    // Retrieve images for the current product
                                    $product_id = $row['product_id'];
                                    $result = mysqli_query($conn, "SELECT * FROM image WHERE product_id = $product_id");
                                    $images = mysqli_fetch_all($result, MYSQLI_ASSOC);
                                ?>

                                <?php 
                                
                                    foreach ($images as $image): 
                                
                                ?>
                                        <img src="<?= $image['path'] ?>" height="100" width="100" alt="Product Image">

                                <?php

                                    endforeach; 

                                ?>

                            </td>
                            <td>
                                <a href = "edit_product.php?edit=<?php echo $row['product_id']; ?>" class = "edit-product-button"><i class="fas fa-edit"></i> Edit</a><br>
                                <a href = "product_list.php?delete=<?php echo $row['product_id']; ?>" class = "delete-product-button"><i class="fas fa-trash"></i> Delete</a>
                            </td>
                        </tr> 

                    <?php 

                        endforeach; 

                    ?>

                </table>

            </div>

        </div>
    </body>

</html>